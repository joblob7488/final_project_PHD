import numpy as np
import sounddevice as sd
import serial
import time
from scipy.io.wavfile import read
from scipy import signal
from matplotlib import pyplot as plt

USB_port = 'COM6'
baudrate = 921600 


# Reading audio signal, did not work as we planned, and was therefore not used
# start_time = time.time()
# received_data = []
# # Reading data send from UART transmitter on FPGA
# with serial.Serial(USB_port, baudrate, timeout=3, bytesize=8) as ser:
#     while time.time() - start_time < 6:
#         received_data.append(ser.read()) 
        
# audio_data = []
# #Converting received data
# for i in range(len(received_data)):
#     audio_data.append(int.from_bytes(received_data[i], byteorder='big'))

# with open("audio_data.txt", "w") as file:
#     for line in audio_data:
#         file.write(str(line) + "\n")    

# Since we cant read from the FPGA, we read from original soundclip instead. 

duration = 10
file_path = "Audio signal 1.wav" 
fs, audio_data = read(file_path)
numtaps = 101 

def find_noisy_freq(freqs_axis, data_magnitude):
    noisy_f = freqs_axis[np.argmax(data_magnitude)] 
    print('Noisy frequency found to be: ', noisy_f , ' Hz')
    return noisy_f

def get_audio_fft(audio_data, fs):
    audio_data_fft = np.fft.fft(audio_data)
    magnitude = abs(audio_data_fft)
    freqs = np.fft.fftfreq(len(audio_data), d=1/fs)
    
    return freqs[:len(freqs)//2], magnitude[:len(magnitude)//2] 

def plot_spectrum(freqs_axis, data_magnitude, noisy_f, title):
    
    magnitude_db = 20*np.log10(data_magnitude + + 1e-10)
    magnitude_normalized = magnitude_db - max(magnitude_db)
    
    plt.plot(freqs_axis, magnitude_normalized, color='orange')
    plt.axvline(noisy_f, label=str(noisy_f)+' Hz', linestyle='--')
    plt.xlim(0, 2000)
    plt.xlabel('Frequency [Hz]')
    plt.ylabel('Amplitude [dBV]')
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.show()
    
# Calculate FFT and finding noisy frequency
freqs_axis, audio_data_fft_magnitude = get_audio_fft(audio_data, fs)
noisy_f = find_noisy_freq(freqs_axis, audio_data_fft_magnitude)
plot_spectrum(freqs_axis, audio_data_fft_magnitude, noisy_f, "Frequency Spectrum of Audio Signal")
noisy_f_normalized = noisy_f / (fs/2)

# Find filter coefficients
filter_coefficients = signal.firwin(numtaps, [noisy_f - 900, noisy_f + 900], pass_zero=True, fs=fs)

# Write coefficients to file
with open("Filter coefficients.txt", "w") as file:
    for coeff in filter_coefficients:
        file.write(str(int(coeff*2**23)) + "\n")
        
# Plot filter response given the calculated coefficients
w, h = signal.freqz(filter_coefficients, worN=8000, fs=fs)
plt.figure(figsize=(10, 6))
plt.subplot(2, 1, 1)
plt.plot(w, 20 * np.log10(abs(h)), label='Magnitude Response (dB)')
plt.title('FIR Band Stop Filter Frequency Response')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Amplitude (dB)')
plt.grid()
plt.legend()
plt.show()
     
# Filter audio signal
audio_filtered = signal.lfilter(filter_coefficients, 1.0, audio_data)

# Find FFT of filtered audio signal and plot the spectrum
filtered_freqs_axis, filtered_audio_fft_magnitude = get_audio_fft(audio_filtered, fs)
plot_spectrum(filtered_freqs_axis, filtered_audio_fft_magnitude, noisy_f, "Frequency Spectrum of Filtered Audio Signal")   
        
        
# Writing to filter coefficients to the FPGA
# filter_coefficients_bytes = []
# received_data = []  

# with serial.Serial(USB_port, baudrate, timeout=3) as ser:
#     for coeff in filter_coefficients:
#         x = int(coeff*2**23).to_bytes(3, byteorder='big', signed=True)
#         ser.write(x)
 
        

